Lamp sprite references and current spark RSIs.

lamp-sprites: upstream light-tube 32x32, light-small 38x38, strobe_light 32x32.
current-spark-sprites: existing spark sheets to redraw; their positioning matches the old lamp art.
Keep the PNG and meta.json files together in each RSI folder.
